# ESP32-EVB
ESP32 WiFi / BLE development board with Ethernet, Relays, microSD card, GPIOs made with KiCAD
